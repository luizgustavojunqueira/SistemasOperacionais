# Trabalho 2 - Sistemas Operacionais

Para mudar o escalonador usado, mude a variável SCHEDULER_TYPE definida no arquivo thread.h

TRUE = Por tempo de cpu
FALSE = Round Robin (FCFS)